<?php
require_once (dirname(dirname(__FILE__)) . '/cmpgenerator.class.php');
class CmpGenerator_mysql extends CmpGenerator {}