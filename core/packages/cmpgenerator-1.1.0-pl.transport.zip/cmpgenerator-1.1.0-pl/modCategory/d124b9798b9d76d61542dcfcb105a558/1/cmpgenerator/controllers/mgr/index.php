<?php
/**
 * Loads the home page.
 */

include 'home.php';
