<?php
$xpdo_meta_map['CmpGenerator']= array (
  'package' => 'cmpgenerator',
  'table' => 'cmpgenerator',
  'fields' => 
  array (
    'package' => '',
    'database' => '',
    'tables' => '',
    'table_prefix' => '',
    'build_scheme' => '1',
    'build_package' => '1',
    'create_date' => NULL,
    'last_ran' => NULL,
  ),
  'fieldMeta' => 
  array (
    'package' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'database' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '128',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'tables' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'table_prefix' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'build_scheme' => 
    array (
      'dbtype' => 'int',
      'precision' => '1',
      'phptype' => 'boolean',
      'null' => true,
      'default' => '1',
    ),
    'build_package' => 
    array (
      'dbtype' => 'int',
      'precision' => '1',
      'phptype' => 'boolean',
      'null' => true,
      'default' => '1',
    ),
    'create_date' => 
    array (
      'dbtype' => 'datetime',
      'phptype' => 'datetime',
      'null' => true,
    ),
    'last_ran' => 
    array (
      'dbtype' => 'datetime',
      'phptype' => 'datetime',
      'null' => true,
    ),
  ),
);
