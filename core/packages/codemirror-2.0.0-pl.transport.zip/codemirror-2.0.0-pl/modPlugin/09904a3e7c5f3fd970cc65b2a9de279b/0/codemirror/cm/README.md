# CodeMirror 2

CodeMirror 2 is a rewrite of [CodeMirror
1](http://github.com/marijnh/CodeMirror). The docs live
[here](http://codemirror.net/2/manual.html), and the project page is
[http://codemirror.net/2/](http://codemirror.net/2/).
